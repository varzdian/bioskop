<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller
{